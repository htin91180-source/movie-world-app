# Movie World — Android APK Starter

This project wraps the Movie World HTML prototype in a basic Android WebView app.

## Build an APK with GitHub Actions (phone-friendly)

1. Create a GitHub repository named `movie-world-app`.
2. Upload **all files and folders** from this project ZIP to the repository's main branch. Keep the `.github/workflows/build-apk.yml` path intact.
3. Open the repository's **Actions** tab.
4. Choose **Build Movie World APK**.
5. Tap **Run workflow** (or wait for the first push-triggered build).
6. When the run completes, open it and download the `Movie-World-debug-APK` artifact.
7. Extract the downloaded artifact ZIP on your Android phone; install `app-debug.apk`. If Android asks, allow installation from that browser/files app.

## Notes

- This produces a **debug APK** for testing and direct sharing, not a signed release APK for Google Play.
- The HTML is stored locally in `app/src/main/assets/index.html`.
- External trailer searches open in the browser. An internet connection is needed for those links.
- Use only videos, posters, and other material you have permission to distribute.
